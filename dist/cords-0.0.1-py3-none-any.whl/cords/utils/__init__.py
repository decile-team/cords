# __init__.py
# Author: Krishnateja Killamsetty <krishnatejakillamsetty@gmail.com>


from .custom_dataset import CustomDataset
from .custom_dataset import load_dataset_custom
from .custom_dataset import load_mnist_cifar


__version__ = '0.0.1'