# __init__.py
# Author: Krishnateja Killamsetty <krishnatejakillamsetty@gmail.com>


__version__ = '0.0.1'