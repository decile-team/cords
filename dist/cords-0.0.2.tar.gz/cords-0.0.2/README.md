# CORDS: COResets and Data Subset selection

## Installation

1. [Python](https://www.python.org/) version 3.7

2. [PyTorch](https://pytorch.org/) version 1.4.0