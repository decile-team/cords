from .omp_solvers import OrthogonalMP_REG_Parallel
from .omp_solvers import OrthogonalMP_REG

__version__ = '0.0.4'